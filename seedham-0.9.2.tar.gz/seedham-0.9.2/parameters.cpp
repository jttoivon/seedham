bool use_markov_background=false;
bool use_positional_background=false;
bool use_two_strands=false;
bool use_pseudo_counts=false;
bool use_submotif=false;
bool use_em=true;
bool reestimate_error_rate=true;
bool use_logodds_score=true;
bool print_alignment=false;
bool count_palindromes_twice = false;

