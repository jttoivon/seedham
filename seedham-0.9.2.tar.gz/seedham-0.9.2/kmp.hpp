#include <string>

int
KMP(const std::string& t, const std::string& p);

int
KMP_first_occurence(const std::string& t, const std::string& p);
